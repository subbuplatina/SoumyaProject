package com.citi.testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.citi.pages.Homepage;

public class SmokeTesting {

	
	@Test
	public void soumya() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "Resources//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		
		Homepage homepage = new Homepage(driver);
		
		//homepage.launchApp();
		//homepage.searchText("Monument Bank PA USA Locations");
		homepage.launchApp();
		Reporter.log("Google page is opened");
		
		homepage.searchText("selenium automation testing");
		Reporter.log("\nSearch of selenium automation testing is done");
		
		Thread.sleep(2000);
		
		homepage.closeApp();
		Reporter.log("Google Page is closed");
	}
	@Test
	public void anusha() {
		Reporter.log("Test method for anusha test case");
	}

}
