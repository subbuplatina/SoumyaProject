package com.citi.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Homepage {
	@FindBy(name = "q")
	public WebElement txtSearchBox;
	WebDriver driver;

	public void launchApp() {
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://www.google.com");

	}

	public void closeApp() {
		driver.close();
		driver.quit();

	}

	public void searchText(String search) {
		txtSearchBox.sendKeys(search);
	}

	public Homepage(WebDriver d) {
		driver = d;
		PageFactory.initElements(driver, this);

	}

}
