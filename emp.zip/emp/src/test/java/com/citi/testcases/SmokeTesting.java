package com.citi.testcases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.citi.pages.Homepage;

public class SmokeTesting {
	WebDriver driver;

	@BeforeSuite
	public void setup() {
		System.setProperty("webdriver.chrome.driver", "Resources//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
	}
	
	@Test
	public void soumya() throws InterruptedException {
		Homepage homepage = new Homepage(driver);
		homepage.launchApp();
		Reporter.log("Google page is opened");
		
		homepage.searchText("selenium automation testing");
		Reporter.log("\nSearch of selenium automation testing is done");
		
		Thread.sleep(2000);
	}
	@Test
	public void anusha() throws InterruptedException {
		Homepage homepage = new Homepage(driver);
		homepage.launchApp();
		Reporter.log("Google page is opened");
		
		homepage.searchText("Madhura and Soumya good girls");
		Reporter.log("\nSearch of selenium automation testing is done");
		
		Thread.sleep(2000);
		Reporter.log("Test method for anusha test case");
	}
	@Test
	public void madura() {
		Reporter.log("This is madura");
	}
	@AfterSuite
	public void tearDown() {
		driver.close();
		driver.quit();
		Reporter.log("Google Page is closed");		
	}

}
