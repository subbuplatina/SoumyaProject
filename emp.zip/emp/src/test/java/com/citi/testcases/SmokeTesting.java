package com.citi.testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.citi.pages.Homepage;

public class SmokeTesting {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "Resources//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		Homepage homepage = new Homepage(driver);
		
		homepage.launchApp();
		homepage.searchText("Monument Bank PA USA Locations");
		
		Thread.sleep(2000);
		
		homepage.closeApp();
		

	}

}
