package com.citi.regression;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class Regression1 {
	@Test
	public void abcd() {
		Reporter.log("This method is from Regression1 java class inside com.citi.Regression1");
	}

}
