package com.citi.regression;


import org.testng.Reporter;
import org.testng.annotations.Test;

public class Regression2 {
	@Test
	public void abcd() throws Exception {
		Reporter.log("This method is from Regression2 java class inside com.citi.Regression2");
		throw new Exception("test failed");
	}
}
