package com.citi.smoke;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class Smoke2 {
	@Test
	public void abcd() {
		Reporter.log("This method is from Smoke2 java class inside com.citi.smoke");
	}
}
