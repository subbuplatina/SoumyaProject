package com.citi.smoke;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class Smoke1 {
	
	@Test
	public void abcd() {
		Reporter.log("This method is from Smoke1 java class inside com.citi.smoke");
	}

}
